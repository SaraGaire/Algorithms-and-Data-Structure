#ifndef MERGESORT_H
#define MERGESORT_H

#include <iostream>
#include <vector>
#include <chrono>

void merge(std::vector<int> &arr, std::vector<int> &left, std::vector<int> &right) {
    size_t i = 0, j =0, k = 0;
    while(i < left.size() && j < right.size()) {
        if(left[i] < right[j]) {
            arr[k] = left[i];
            i++;
        }
        else{
            arr[k] = right[j];
            j++;
        }
        k++;
    }

    while(i < left.size()) {
        arr[k] = left[i];
        i++;
        k++;
    }

    while(j < right.size()) {
        arr[k] = right[j];
        j++;
        k++;
    }
}

void insertionsort(std::vector<int> &arr) {
    for(size_t i = 1; i < arr.size(); i++) {
        int temp = arr[i];
        int j = i - 1;
        while(j >= 0 && arr[j] > temp) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j+1] = temp;
    }
}

void mergesort(std::vector<int> &arr, int x) {
    size_t k = x;
    if(arr.size() > k) {
        int mid = arr.size()/2;
        std::vector<int> left(arr.begin(), arr.begin() + mid);
        std::vector<int> right(arr.begin()+mid, arr.end());

        mergesort(left, k);
        mergesort(right, k);

        merge(arr, left, right);
    }
    insertionsort(arr);
}

std::vector<int> averageCase(int n) {
    std::vector<int> sequence;
    for(int i = 0; i < n; i++) {
        sequence.push_back(rand() % 60);
    }
    return sequence;
}

std::vector<int> WorstCase(int n) {
    std::vector<int> sequence;
    for(int i = n; i > 0; i--) {
        sequence.push_back(i);
    }
    return sequence;
}

std::vector<int> BestCase(int n) {
    std::vector<int> sequence;
    for(int i = 0; i < n; i++) {
        sequence.push_back(i);
    }
    return sequence;
}

std::chrono::microseconds measureTimeTaken(std::vector<int> &arr, int k) {
    std::chrono::high_resolution_clock::time_point start = std::chrono::high_resolution_clock::now();
    mergesort(arr, k);
    std::chrono::high_resolution_clock::time_point end = std::chrono::high_resolution_clock::now();
    std::chrono::microseconds totalTime = std::chrono::duration_cast<std::chrono::microseconds>(end-start);
    return totalTime;
}

#endif
