#include "mergesort.h"
#include <ctime>
#include <fstream>

int main() {
    int n = 1000; 
    
    std::vector<std::chrono::microseconds> avgTime, worstTime, bestTime;
    std::vector<int> avgKvalue, worstKvalue, bestKvalue;

    for(int k = 1; k <= 500; k+=10) {
        std::time_t curr_time = std::time(nullptr);
        std::srand(static_cast<unsigned int>(curr_time));

        std::vector<int> average = averageCase(n);
        std::vector<int> worst = WorstCase(n);
        std::vector<int> best = BestCase(n);

        // recording time taken for different k in vectors
        avgKvalue.push_back(k);
        avgTime.push_back(measureTimeTaken(average, k));
        worstKvalue.push_back(k);
        worstTime.push_back(measureTimeTaken(worst, k));
        bestKvalue.push_back(k);
        bestTime.push_back(measureTimeTaken(best, k));
    }
        
        // writing the data into text files

    std::ofstream outputFile("average.txt");
    if (outputFile.is_open()) {
        for (size_t i = 0; i < avgTime.size(); ++i) {
            outputFile << avgKvalue[i] << " " << avgTime[i].count() << std::endl;
        }
        outputFile.close();
        std::cout << "Average Data exported successfully." << std::endl;
    } else {
        std::cerr << "Unable to export data." << std::endl;
        return 1;
    }

    std::ofstream outputFile1("worst.txt");
    if (outputFile1.is_open()) {
        for (size_t i = 0; i < worstTime.size(); ++i) {
            outputFile1 << worstKvalue[i] << " " << worstTime[i].count() << std::endl;
        }
        outputFile1.close();
        std::cout << "Worst Data exported successfully." << std::endl;
    } else {
        std::cerr << "Unable to export data." << std::endl;
        return 1;
    }

    std::ofstream outputFile2("best.txt");
    if (outputFile2.is_open()) {
        for (size_t i = 0; i < bestTime.size(); ++i) {
            outputFile2 << bestKvalue[i] << " " << bestTime[i].count() << std::endl;
        }
        outputFile2.close();
        std::cout << "Best Data exported successfully." << std::endl;
    } else {
        std::cerr << "Unable to export data." << std::endl;
        return 1;
    }

    return 0;
}