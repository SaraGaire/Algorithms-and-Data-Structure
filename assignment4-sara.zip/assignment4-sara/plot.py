import matplotlib.pyplot as plt

# Read the data from the text files
def read_data(datatiming.txt):
    k_values = []
    times = []
    with open(datatiming.txt, 'r') as file:
        for line in file:
            k, time = line.split()
            k_values.append(int(k))
            times.append(int(time))
    return k_values, times

# Read the data from the files
avg_k, avg_time = read_data("average.txt")
worst_k, worst_time = read_data("worst.txt")
best_k, best_time = read_data("best.txt")

# Create the plot
plt.figure(figsize=(10, 6))

# Plot each case
plt.plot(avg_k, avg_time, label="Average Case", color='blue', marker='o')
plt.plot(worst_k, worst_time, label="Worst Case", color='red', marker='x')
plt.plot(best_k, best_time, label="Best Case", color='green', marker='s')

# Add labels and title
plt.xlabel("K Value")
plt.ylabel("Time (microseconds)")
plt.title("Merge Sort Time Complexity: Average, Worst, and Best Case")
plt.legend()

# Show grid
plt.grid(True)

# Show the plot
plt.show()
